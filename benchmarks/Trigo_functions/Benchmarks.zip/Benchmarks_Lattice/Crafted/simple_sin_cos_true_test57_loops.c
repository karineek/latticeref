#include <math.h>
#include <assert.h>

int main()
{
	double theta = 0.0;
	double phi = 4.0;
	double sphere_x = 0.0;
	double temp = 0.0;

	double sin_x, cos_x;

	for (int i=0; i < 3; i++)
	{
           theta += 0.1; phi = 4.0;
	   sin_x = sin(theta);
	   cos_x = cos(theta);

	   for (int j=0; j < 3; j++)
	   { 
		phi += 0.1;	
		double cos_y = cos(phi);
		double sin_y = sin(phi);
		double sum = (sin_x*cos_y + cos_x*sin_y);
	
		sphere_x += sum;

		double x_y = phi + theta;		
		temp += sin(x_y);
            }
	}

	assert(sphere_x == temp); // UNSAT
	assert(sphere_x < 0); // UNSAT
	assert(sphere_x >= 0); // SAT
        assert(0); // SAT
}
