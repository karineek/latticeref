1. crafted_x_cos: tests for lattice cosine fact. Single call of consine library function.
2. crafted_x_sin: tests for lattice sine fact. Single call of sine library function.
3. simple_sin_cos_true_testx_no_loops: Crafted for facts with both sine and cosine calls.
4. Simple_sin_cos_true_testx_loops: Crafted for facts/other benchmarks with both sine and cosine calls.
